package Crypt::SSLeay::Conn;
require Crypt::SSLeay;
1;
