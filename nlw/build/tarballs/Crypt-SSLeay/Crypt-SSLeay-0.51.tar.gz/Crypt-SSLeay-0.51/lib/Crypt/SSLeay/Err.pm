package Crypt::SSLeay::Err;
require Crypt::SSLeay;
1;
