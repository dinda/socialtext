package t::TestB;
use t::TestA -Base;
