=head1 NAME

Pod::Stuff - dummy testing pod

=head1 DESCRIPTION

This isn't really anything, its just some dummy pod code.
And stuff.

Lots of stuff.

=head2 STUFF

For all your stuff [tm]

Stuffit

Mmmm, stuffed pizza bread.

=cut
